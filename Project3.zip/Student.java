package Project2;

public class Student {

	public static int studentID;
	public int studentLevel;
	public int lastName;
	public String firstName;

	public Student(int defaultID, String firstName2, String lastName2, String studentLevel2) {
		// TODO Auto-generated constructor stub
	}

	public void displayStudent() {
		// TODO Auto-generated method stub
		
	}

	public void deactivateStudent() {
		// TODO Auto-generated method stub
		
	}

}
