package Project2;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.util.*;

public class Main{
	//First Print out 
	public static void main(String[] args) {
		System.out.println("  Welcome to Student Management System  ");
		System.out.println(" This system will allow you to manage student. Lets start with the number of sudents this system will have:  ");
		System.out.println("**Welcome to Student Management System**");
		System.out.println("Press '1' to add a student");
		System.out.println("Press '2' to deactivate a student");
		System.out.println("Press '3' to display all students");
		System.out.println("Press '4' to search for a student by ID");
		System.out.println("Press '0' to exit the system");
		
		int size, choice = 1;
		Scanner scanner = new Scanner(System.in);
		int defaultID = 5;
		ArrayList<Student> students;
		
		size = scanner.nextInt();
		students = new ArrayList<Student>(size);
		while(choice != 0){
			int tempID;
			
			menu();
			choice = scanner.nextInt();
	
			scanner.nextLine();
			
			switch (choice) {
			case 1:
				String firstName, lastName, studentLevel;
				System.out.println("Enter first name: ");
				firstName = scanner.nextLine();
				System.out.println("Enter last name: ");
				lastName = scanner.nextLine();
				System.out.println("Enter level of student: ");
				studentLevel = scanner.nextLine();
				Student temp = new Student(defaultID, firstName, lastName, studentLevel);
				
				if(students.size() + 1 < size) {
					students.add(temp);
					
					System.out.println(temp.firstName + " " + temp.lastName + " has been added as a " + temp.studentLevel + " with ID " + Student.studentID);
					System.out.println();
					defaultID++;
				}else {
					System.out.println("  You have the max amount of students implemented	");
				}
				break;
			case 2:
				System.out.println("  Enter the ID for the student you want to deactivate:  ");
				tempID = scanner.nextInt(); 
				scanner.nextLine();
				
				for(int i = 0; i < students.size(); i++) {
					students.get(i);
					if(Student.studentID == tempID)
						students.get(i).deactivateStudent();
				}
				
				break;
			case 3:
				for(int i = 0; i < students.size(); i++) {
					students.get(i).displayStudent();
					System.out.println();
				}
				break;
			case 4:
				boolean isFound = false;
				
				System.out.println("enter the student ID: ");
				tempID = scanner.nextInt();
				
			
				for(int i = 0; i < students.size(); i++) {
					students.get(i);
					if (tempID == Student.studentID) {
						isFound = true;
						students.get(i).displayStudent();
						break;

					}
				}
				if(!isFound)
					System.out.println("cannot find student with ID: " + tempID);
				System.out.println();
				break;
			default:
				 
				System.out.println("Exit the system");
				break;
			}
			
		}
		if(!isFound)
			System.out.println("cannot find student with ID: " + tempID);
		System.out.println();
		break;
	default:	 
		System.out.println("Exit the system");
		break;
	case 5: 
		isFound = false;	
		System.out.println("enter student ID:   ");
		tempID = scanner.nextInt();
		scanner.nextLine();
		System.out.println("enter job:   ");
		String tempJob =  scanner.nextLine();
		System.out.println("enter jobType:   ");
		String tempjobType = scanner.nextLine();	
		for (Student student: students) {
			if (tempID = student.studentID) {
				isFound = true;
				student.assignJob(tempJob, tempJobType);
				System.out.println(student.firstName + "    " + student.lastName + "student has been assigned" + tempJobType + "    " + tempJob);
				break;
	}
	if (isFound)
		System.out.printkn("student NOT found with ID:   " + tempID);
	System.out.println();
	break;
    case 6:
    	for (Student studennt: students)  {
    		if (student.job != null) {
    			System.out.println(student.firstName + "    " + student.lastName);
    			System.out.println("ID - " + student.studentID);
    			System.out.println(student.jobType + "    " + )student.job + "\n");
    		}
    	}
    break;
    default: 
    	System.out.println("Error: try another time \n");
    	break;	
	}
}
	break;
	case 2: 
		tempChoice = 1;
		while (tempChoice !=0) {
			cmsMenu();
			while(!scanner.hasNextInt()) {
				System.out.println("Error: try another time");
				scanner.next();
			}
			tempChoice = scanner.nextInt();	
			scanner.nextLine();
			switch (tempchoice) {
			case 0:
				System.out.println("Existing CMS");
				break;
			case 1:
				File input = new File("Course.txt");
				input.createNewFile();
				System.out.println("enter course ID:   ");
				tempID = scanner.nextInt();
				scanner.nextLine();
				System.out.println("enter course name:    ")
				String tempName = scanner.nextLine();
				System.out.println("confirmation: new course" + tempName + "has been added");
				FileWriter fw = new FileWriter("Courses.txt");
				fw.writye("course ID:    " + tempID + "course name:" + tempName);
				break,
			case 2:
				boolean isFound = false;
				fw = new FileWriter("CourseAssignment.txt");
				input = new FileWriter("CourseAssignment.txt");
				input.createNewFile();
				System.out.println("enter student ID:     ");
				tempID = scanner.nextInt();
				scanner.nextLine();
				for ( Student student : students)
					if (student.studentID = tempID) {
						isFound = true;
						System.out.println("confirmation:    " + student.firstName + "      " + student.lastName + "has been assigned course" + tempCourseID);
						fw.write(student.firstName + "     " + student.lastName + "\nID -" + tempID + "\ncourses:     " + tempCourseID + "\n");
					}
if (!isFound)
	System.out.println("cannot find student with ID:   " + tempID);
System.out.println();
fw.close();
break;
			case 3:
				BufferedReader br = new BufferedReader (new FilerReader("CourseAssignment.txt"));
				String line;
				while ((line = br.readLine()) ! = null );
				System.out.println(line);
				break;
				default:
					System.out.println("error: try again later \n");
					break;
			}
		}
		scanner.close();
}
public static void studentMenu() {
    System.out.println("***Welcome to SMS***");
    System.out.println("Press 1 to add a student");
    System.out.println("Press 2 to deactivate a student");
    System.out.println("Press 3 to display all students");
    System.out.println("Press 4 to search for a student by ID");
    System.out.println("Press 5 to assign on-campus job");
    System.out.println("Press 6 to display all students with on-campus jobs");
    System.out.println("Press 0 to exit SMS");
}
public static void cmsMenu() {
    System.out.println("***Welcome to CMS***");
    System.out.println("Press 1 to add a new course");
    System.out.println("Press 2 to assign student a new course");
    System.out.println("Press 3 to display student with assigned courses");
    System.out.println("Press 0 to exit CMS");
}
public static void mainMenu() {
    System.out.println("***Welcome to Student and Course Management System***");
    System.out.println("Press 1 for Student Management System (SMS)");
    System.out.println("Press 2 for Course Management System (CMS)");
    System.out.println("Press 0 to exit");
    System.out.println("have a good day");
}
}