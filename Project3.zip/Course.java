public class Course {
    int courseID;
    String courseName;

    public Course (int id, String name){
        courseID = id;
        courseName = name;
    }

}
